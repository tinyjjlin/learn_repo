<h2 style="font-size: 14px;">我的公众号：kaitao-1234567</h2>
<a href="https://item.jd.com/12153914.html"><img src="https://github.com/zhangkaitao/shiro-example/blob/master/1.jpg" width = "200" style="align:left"/></a>

<h2 style="font-size: 14px;">我的新书：<a href="https://item.jd.com/12153914.html">《亿级流量网站架构核心技术》</a></h2>
<a href="https://item.jd.com/12153914.html">《亿级流量网站架构核心技术》</a>一书总结并梳理了亿级流量网站高可用和高并发原则，通过实例详细介绍了如何落地这些原则。书希这本书能成为大家的案头书，遇到问题随时查阅。也希望成为互联网公司面试宝典。
<a href="https://item.jd.com/12153914.html"><img src="https://github.com/zhangkaitao/shiro-example/blob/master/2.png" width = "400" style="align:left"/></a>


<h2 style="font-size: 14px;"><a href="http://jinnianshilongnian.iteye.com/blog/2018398" target="_blank">Shiro目录</a> | <a href="http://jinnianshilongnian.iteye.com/blog/2018398" target="_blank">点击下载PDF版</a></h2>
<p style="font-size: 14px;"><a href="/blog/2018936" target="_blank">第一章&nbsp; Shiro简介</a></p>
<p style="font-size: 14px;"><a href="/blog/2019547" target="_blank">第二章&nbsp; 身份验证</a></p>
<p style="font-size: 14px;"><a href="/blog/2020017" target="_blank">第三章&nbsp; 授权</a></p>
<p style="font-size: 14px;"><a href="/blog/2020820" target="_blank">第四章&nbsp; INI配置</a></p>
<p style="font-size: 14px;"><a href="/blog/2021439" target="_blank">第五章&nbsp; 编码/加密</a></p>
<p style="font-size: 14px;"><a href="/blog/2022468" target="_blank">第六章&nbsp; Realm及相关对象</a></p>
<p style="font-size: 14px;"><a href="/blog/2024723" target="_blank">第七章&nbsp; 与Web集成</a></p>
<p style="font-size: 14px;"><a href="/blog/2025656" target="_self">第八章 拦截器机制</a></p>
<p style="font-size: 14px;"><a href="/blog/2026398" target="_blank">第九章 JSP标签</a></p>
<p style="font-size: 14px;"><a href="/blog/2028675" target="_blank">第十章&nbsp; 会话管理</a></p>
<p style="font-size: 14px;"><a href="/blog/2029217" target="_blank">第十一章&nbsp; 缓存机制</a></p>
<p style="font-size: 14px;"><a href="/blog/2029717" target="_blank">第十二章&nbsp; 与Spring集成</a></p>
<p style="font-size: 14px;"><a href="/blog/2031823" target="_blank">第十三章&nbsp; RememberMe</a></p>
<p style="font-size: 14px;"><a href="/blog/2036420" target="_blank">第十四章&nbsp; SSL</a></p>
<p style="font-size: 14px;"><a href="/blog/2036730" target="_blank">第十五章&nbsp; 单点登录</a></p>
<p style="font-size: 14px;"><a href="/blog/2037222" target="_blank">第十六章&nbsp; 综合实例</a></p>
<p style="font-size: 14px;"><a href="/blog/2038646" target="_blank">第十七章&nbsp; OAuth2集成</a></p>
<p style="font-size: 14px;"><a href="/blog/2039760" target="_blank">第十八章 并发登录人数控制</a></p>
<p style="font-size: 14px;"><a href="/blog/2040929" target="_blank">第十九章 动态URL权限控制</a></p>
<p style="font-size: 14px;"><a href="/blog/2041909" target="_blank">第二十章 无状态Web应用集成</a></p>
<p style="font-size: 14px;"><a href="/blog/2044616" target="_blank">第二十一章 授予身份及切换身份</a></p>
<p style="font-size: 14px;"><a href="/blog/2046041" target="_blank">第二十二章 集成验证码</a></p>
<p style="font-size: 14px;"><a href="/blog/2047168" target="_blank">第二十三章 多项目集中权限管理及分布式会话</a></p>
<p style="font-size: 14px;"><a href="/blog/2047643" target="_blank">第二十四章 在线会话管理</a></p>
<p style="font-size: 14px;">&nbsp;</p>
<p style="font-size: 14px;">示例工程是Maven工程，需要了解Maven基础。</p>
